# Final project state for HTML 320 Stylin' With Sass

This is how the folders and files should look at the end of the
project.

## A note on the watcher

You may want to copy the `package.json` file from here to other
projects, but it's just as easy to make your own, since almost all of
it is automated.

You can read more about it in the project wiki.
