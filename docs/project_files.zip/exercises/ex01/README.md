# Exercise 01: Create SCSS Files

1. Add the `ex01` folder to Prepros projects (Drag and drop into projects area).

2. Open the `ex01` folder in your editor.

3. Create a directory called `sass` in the exercise root.

4. Move and rename the two CSS files to the `sass` directory:
  * `css/reset.css` becomes `sass/reset.scss`
  * `css/styles.css` becomes `sass/styles.scss`

**NOTE:** you are both *moving* AND *renaming* the files.

5. in Prepros, refresh the ex01 project and open the live preview.
