# Exercise 11: Clean up

Not really introducing anything new here, just refactoring
a few things, and collecting things together.

We split out objects and components into their pieces in 
subdirectory. Let's do the same with the other layers.

We'll also move the base partials for each layer into
the subdirectory and rename it to `_index.scss`. By convention,
the default file under a directory is based as `index` 
(e.g. `index.html`, `index.js`).

