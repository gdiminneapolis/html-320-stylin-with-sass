# Move the reset to the general file

Move the line where you import the reset file from
`sass/_overrides.scss` to the `sass/_general.scss` file.

# Extract the elements

Find the elements (styles on HTML elements like `body`, `h1`, `p`,
etc.) and move them to the `sass/_elements.scss` file.
